﻿using System;
using ChessBoardModel;

namespace ChessBoardConsoleApp
{
    public class Progam
    {

        public static void Main(string [] args)
        {
            Run();
        }

        static Board myBoard = new Board(8);
        public static void Run()
        {
            // show the empty chessboard
            printGrid(myBoard);

            // get the location of the chess piece
            Cell myLocation = setCurrentCell();

            // used to select the piece
            string piece = selectPiece();

            // calculate and mark the cells where legal moves are possible.
            myBoard.MarkNextLegalMoves(myLocation, piece);

            // show the chess board. Use . for an empty square, X for the piece location and + for a possible legal move
            printGrid(myBoard);

            // wait for another return key to end the program
            Console.ReadLine();

            Run();

        }

        public static string selectPiece()
        {
            string piece = "";

            Console.WriteLine("Please select a number of which piece you would like to test");
            Console.WriteLine("1) Knight \n2) King \n3) Rook \n4) Queen \n5) Bishop \n");
            int selector = int.Parse(Console.ReadLine());

            switch (selector)
            {
                case 1:
                    piece = "Knight";
                    break;
                case 2:
                    piece = "King";
                    break;
                case 3:
                    piece = "Rook";
                    break;
                case 4:
                    piece = "Queen";
                    break;
                case 5:
                    piece = "Bishop";
                    break;
                default:
                    selectPiece();
                    break;
            }

            return piece;

        }

        static public void printGrid(Board myBoard)
        {
            for (int i = 0; i < myBoard.Size; i++)
            {
                Console.WriteLine("+---+---+---+---+---+---+---+---+");
                for (int j = 0; j < myBoard.Size; j++)
                {

                    if (myBoard.theGrid[i, j].CurrentlyOccupied)
                    {
                        // piece location
                        Console.Write("| X ");
                    }
                    else if (myBoard.theGrid[i, j].LegalNextMove)
                    {
                        // possible moves
                        Console.Write("| + ");
                    }
                    else
                    {
                        // blank cell
                        Console.Write("|   ");
                    }
                }
                Console.Write("|");
                Console.WriteLine();

            }
            Console.WriteLine("+---+---+---+---+---+---+---+---+");
            Console.WriteLine("\n=================================");


        }
        static public Cell setCurrentCell()
        {
            bool done = false;
            int currentRow = 0;
            int currentCol = 0;
            while (!done)
            {
                try
                {
                    Console.Out.Write("Enter your current row number: ");
                    currentRow = int.Parse(Console.ReadLine());



                    Console.Out.Write("Enter your current column number: ");
                    currentCol = int.Parse(Console.ReadLine());

                    if (currentCol > myBoard.Size || currentRow > myBoard.Size)
                    {
                        var error = $"The size of the board is {myBoard.Size} by {myBoard.Size}\nPlease enter numbers between 0 and {myBoard.Size}";
                        Console.WriteLine(error);

                    }
                    myBoard.theGrid[currentRow, currentCol].CurrentlyOccupied = true;

                    done = true;
                }
                catch (Exception)
                {
                    Console.WriteLine("PLease enter a number between 0 - 7");
                }
            }

            return myBoard.theGrid[currentRow, currentCol];
        }
    }
}
